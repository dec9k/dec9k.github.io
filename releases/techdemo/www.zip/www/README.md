An Elysian Elegy
